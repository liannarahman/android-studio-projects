package com.example.outthechat.view;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.widget.RemoteViews;

import com.example.outthechat.R;
import com.example.outthechat.model.GroupDatabase;
import com.example.outthechat.model.Event;
import com.example.outthechat.model.EventDao;

import java.util.List;

public class MyWidget extends AppWidgetProvider {

    // Updates a single widget instance
    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        GroupDatabase db = GroupDatabase.getInstance(context);
        EventDao eventDao = db.eventDao();

        List<Event> events = eventDao.getAllEvents();

        String widgetText;
        if (events == null || events.isEmpty()) {
            widgetText = "No events yet!";
        } else {
            Event latest = events.get(events.size() - 1);
            widgetText = "Next: " + latest.title + " (" + latest.date + ")";
        }

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
        views.setTextViewText(R.id.appwidget_text, widgetText);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    // Called whenever widgets should be updated
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    // Helper method to manually refresh all widgets (called from CreateEventActivity)
    public static void refreshWidget(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, MyWidget.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);

        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }
}
