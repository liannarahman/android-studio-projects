package com.example.outthechat.model;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Group.class, Event.class}, version = 4, exportSchema = false)
public abstract class GroupDatabase extends RoomDatabase {

    private static GroupDatabase instance;

    public abstract GroupDao groupDao();
    public abstract EventDao eventDao();

    public static synchronized GroupDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                            context.getApplicationContext(),
                            GroupDatabase.class,
                            "GroupDB"
                    )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
