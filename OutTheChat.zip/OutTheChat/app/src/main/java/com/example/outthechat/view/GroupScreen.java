package com.example.outthechat.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.outthechat.R;
import com.example.outthechat.model.Group;
import com.example.outthechat.model.GroupDao;
import com.example.outthechat.model.GroupDatabase;

import java.util.ArrayList;
import java.util.List;

public class GroupScreen extends AppCompatActivity {

    private GroupDatabase db;
    private GroupDao groupDao;
    private ArrayAdapter<String> adapter;
    private List<String> groupDisplayList;
    private List<Group> groupList;
    private ListView listGroups;
    private Button btnAddGroup, btnBackHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_group);
        // Show a quick reminder for 5 seconds
        android.widget.Toast reminderToast = android.widget.Toast.makeText(
                this,
                "💡 Long press a group to delete it",
                android.widget.Toast.LENGTH_LONG
        );
        reminderToast.show();

// Extend the Toast duration to roughly 5 seconds
        new android.os.Handler().postDelayed(reminderToast::cancel, 5000);


        // Initialize views
        listGroups = findViewById(R.id.listGroups);
        btnAddGroup = findViewById(R.id.btnAddGroup);

        // Back to Home button (added programmatically)
        btnBackHome = new Button(this);
        btnBackHome.setText("Back to Home");
        btnBackHome.setOnClickListener(v -> {
            Intent intent = new Intent(GroupScreen.this, HomeScreen.class);
            startActivity(intent);
            finish();
        });
        ((LinearLayout) listGroups.getParent()).addView(btnBackHome);

        // Setup Room Database
        db = Room.databaseBuilder(getApplicationContext(), GroupDatabase.class, "GroupDB")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
        groupDao = db.groupDao();

        // Load saved groups
        groupDisplayList = new ArrayList<>();
        groupList = new ArrayList<>();
        loadGroups();

        // Setup adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, groupDisplayList);
        listGroups.setAdapter(adapter);

        //  When a group is clicked, open its event list
        listGroups.setOnItemClickListener((parent, view, position, id) -> {
            Group selectedGroup = groupList.get(position);
            Intent intent = new Intent(GroupScreen.this, GroupDetailsActivity.class);
            intent.putExtra("groupId", selectedGroup.getId());
            startActivity(intent);
        });

        // Add group popup
        btnAddGroup.setOnClickListener(v -> showAddGroupDialog());

        // Long press to delete
        listGroups.setOnItemLongClickListener((parent, view, position, id) -> {
            Group selected = groupList.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Delete Group")
                    .setMessage("Are you sure you want to delete \"" + selected.getName() + "\"?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        groupDao.deleteGroup(selected);
                        loadGroups();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });
    }

    private void showAddGroupDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Create a Group");

        // Layout for name
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 10);

        final EditText inputName = new EditText(this);
        inputName.setHint("Group name");
        layout.addView(inputName);

        final EditText inputDesc = new EditText(this);
        inputDesc.setHint("Group description (optional)");
        layout.addView(inputDesc);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String name = inputName.getText().toString().trim();
            String desc = inputDesc.getText().toString().trim();

            if (!name.isEmpty()) {
                groupDao.insertGroup(new Group(name, desc));
                loadGroups();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void loadGroups() {
        groupDisplayList.clear();
        groupList = groupDao.getAllGroups();

        for (Group g : groupList) {
            String displayText = g.getName();
            if (g.getDescription() != null && !g.getDescription().isEmpty()) {
                displayText += " — " + g.getDescription();
            }
            groupDisplayList.add(displayText);
        }

        if (adapter != null) adapter.notifyDataSetChanged();
    }
}
