package com.example.outthechat.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.example.outthechat.R;

public class HomeScreen extends AppCompatActivity {

    private Button btnAddGroup, btnAddEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnAddGroup = findViewById(R.id.btnAddGroup);
        btnAddEvent = findViewById(R.id.btnAddEvent);

        btnAddGroup.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreen.this, GroupScreen.class);
            startActivity(intent);
        });

        btnAddEvent.setOnClickListener(v -> {


        });

        //Event screen
        Button btnCreateEvent = findViewById(R.id.btnCreateEvent);
        btnCreateEvent.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreen.this, CreateEventActivity.class);
            startActivity(intent);
        });

    }

}
