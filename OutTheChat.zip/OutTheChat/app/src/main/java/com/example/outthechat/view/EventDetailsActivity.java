package com.example.outthechat.view;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.outthechat.model.Event;
import com.example.outthechat.model.EventDao;
import com.example.outthechat.model.Group;
import com.example.outthechat.model.GroupDao;
import com.example.outthechat.model.GroupDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EventDetailsActivity extends AppCompatActivity {

    private GroupDatabase db;
    private GroupDao groupDao;
    private EventDao eventDao;

    private EditText eventNameInput, eventDateInput;
    private Spinner groupSpinner, categorySpinner;
    private TextView costEstimateView;
    private Button btnSaveEvent, btnBack;
    private Map<String, String> costLevels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Scroll layout
        ScrollView scrollView = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 80, 60, 60);
        scrollView.addView(layout);

        // Title
        TextView title = new TextView(this);
        title.setText("Event Details");
        title.setTextSize(30);
        title.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);
        layout.addView(title);

        // Event Name
        eventNameInput = new EditText(this);
        eventNameInput.setHint("Enter Event Name");
        eventNameInput.setTextSize(18);
        layout.addView(eventNameInput);

        // Event Date
        eventDateInput = new EditText(this);
        eventDateInput.setHint("Enter Event Date (e.g., Dec 15, 2025)");
        eventDateInput.setTextSize(18);
        layout.addView(eventDateInput);

        // Group label and dropdown
        TextView groupLabel = new TextView(this);
        groupLabel.setText("Select Group:");
        groupLabel.setTextSize(20);
        groupLabel.setPadding(0, 20, 0, 10);
        layout.addView(groupLabel);

        groupSpinner = new Spinner(this);
        layout.addView(groupSpinner);

        // Category label
        //dropdown
        TextView categoryLabel = new TextView(this);
        categoryLabel.setText("Select Category:");
        categoryLabel.setTextSize(20);
        categoryLabel.setPadding(0, 25, 0, 10);
        layout.addView(categoryLabel);

        categorySpinner = new Spinner(this);
        layout.addView(categorySpinner);

        costEstimateView = new TextView(this);
        costEstimateView.setText("Estimated Cost: —");
        costEstimateView.setTextSize(20);
        costEstimateView.setPadding(0, 25, 0, 25);
        layout.addView(costEstimateView);

        // Save button
        btnSaveEvent = new Button(this);
        btnSaveEvent.setText("Save Event");
        btnSaveEvent.setTextSize(18);
        layout.addView(btnSaveEvent);

        // Back button
        btnBack = new Button(this);
        btnBack.setText("Back");
        btnBack.setTextSize(18);
        btnBack.setOnClickListener(v -> finish());
        layout.addView(btnBack);

        // Apply scroll view
        setContentView(scrollView);

        // Setup database
        db = Room.databaseBuilder(getApplicationContext(), GroupDatabase.class, "GroupDB")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();
        groupDao = db.groupDao();
        eventDao = db.eventDao();

        // Populate group spinner
        List<Group> groups = groupDao.getAllGroups();
        List<String> groupNames = new ArrayList<>();
        groupNames.add("-- Choose Group --");
        for (Group g : groups) {
            groupNames.add(g.getName());
        }

        ArrayAdapter<String> groupAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                groupNames
        );
        groupSpinner.setAdapter(groupAdapter);

        // Category cost level
        costLevels = new HashMap<>();
        costLevels.put("Food", "Medium-High ($25–$60)");
        costLevels.put("Movies", "Medium-High ($20–$50)");
        costLevels.put("Shopping", "High ($70+)");
        costLevels.put("Hanging Out at Home", "Low ($0–$10)");
        costLevels.put("Game Night", "Low-Medium ($10–$30)");

        List<String> categories = new ArrayList<>();
        categories.add("-- Choose Category --");
        categories.addAll(costLevels.keySet());

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                categories
        );
        categorySpinner.setAdapter(categoryAdapter);

        // Update cost estimate automatically
        categorySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                if (position == 0) { // first option "-- Choose Category --"
                    costEstimateView.setText("Estimated Cost: —");
                    costEstimateView.setTextColor(Color.BLACK);
                    return;
                }

                String category = parent.getItemAtPosition(position).toString();
                String level = costLevels.get(category);
                costEstimateView.setText("Estimated Cost: " + level);

                // Change text color based on cost level
                if (level.contains("Low")) {
                    costEstimateView.setTextColor(Color.parseColor("#2E7D32")); // Green
                } else if (level.contains("Medium")) {
                    costEstimateView.setTextColor(Color.parseColor("#FF9800")); // Orange
                } else if (level.contains("High")) {
                    costEstimateView.setTextColor(Color.parseColor("#D32F2F")); // Red
                } else {
                    costEstimateView.setTextColor(Color.BLACK);
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        //  Save Event button
        btnSaveEvent.setOnClickListener(v -> {
            String eventName = eventNameInput.getText().toString().trim();
            String eventDate = eventDateInput.getText().toString().trim();
            int selectedGroup = groupSpinner.getSelectedItemPosition();
            int selectedCategory = categorySpinner.getSelectedItemPosition();

            if (eventName.isEmpty()) {
                Toast.makeText(this, "Please enter an event name.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedGroup == 0 || groups.isEmpty()) {
                Toast.makeText(this, "Please select a group.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedCategory == 0) {
                Toast.makeText(this, "Please select a category.", Toast.LENGTH_SHORT).show();
                return;
            }

            Group selected = groups.get(selectedGroup - 1); // adjust index
            Event newEvent = new Event(eventName, eventDate, "", selected.getId());
            eventDao.insertEvent(newEvent);

            Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
