package com.example.outthechat.model;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Delete;

import java.util.List;

@Dao
public interface GroupDao {

    @Insert
    void insertGroup(Group group);

    @Update
    void updateGroup(Group group);

    @Delete
    void deleteGroup(Group group);

    @Query("SELECT * FROM 'groups'")
    List<Group> getAllGroups();

    @Query("SELECT * FROM 'groups' WHERE id = :id")
    Group getGroupById(int id);
}
