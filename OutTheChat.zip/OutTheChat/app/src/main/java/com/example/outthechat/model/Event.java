package com.example.outthechat.model;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "events",
        foreignKeys = @ForeignKey(
                entity = Group.class,
                parentColumns = "id",
                childColumns = "groupId",
                onDelete = ForeignKey.CASCADE
        )
)
public class Event {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String date;
    public String description;

    public int groupId; // foreign key link

    public Event(String title, String date, String description, int groupId) {
        this.title = title;
        this.date = date;
        this.description = description;
        this.groupId = groupId;
    }
}
