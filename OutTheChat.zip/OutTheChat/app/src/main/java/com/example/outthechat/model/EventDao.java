package com.example.outthechat.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface EventDao {

    @Insert
    void insertEvent(Event event);

    @Update
    void updateEvent(Event event);

    @Delete
    void deleteEvent(Event event);

    @Query("SELECT * FROM events WHERE groupId = :groupId")
    List<Event> getEventsForGroup(int groupId);

    @Query("SELECT * FROM events")
    List<Event> getAllEvents();
}
