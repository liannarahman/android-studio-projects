package com.example.outthechat.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import com.example.outthechat.model.Event;
import com.example.outthechat.model.EventDao;
import com.example.outthechat.model.Group;
import com.example.outthechat.model.GroupDao;
import com.example.outthechat.model.GroupDatabase;
import java.util.ArrayList;
import java.util.List;

public class GroupDetailsActivity extends AppCompatActivity {

    private EventDao eventDao;
    private GroupDao groupDao;
    private ArrayAdapter<String> adapter;
    private List<Event> eventList;
    private List<String> eventDisplayList;
    private int groupId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Layout setup
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 70, 50, 70);

        // Header text (group title)
        TextView header = new TextView(this);
        header.setTextSize(28); // BIG FONT
        header.setTextAlignment(TextView.TEXT_ALIGNMENT_CENTER);
        header.setPadding(0, 0, 0, 40);
        layout.addView(header);

        // ListView for events
        ListView listView = new ListView(this);
        layout.addView(listView);

        // Back button
        Button btnBack = new Button(this);
        btnBack.setText("Back to Groups");
        btnBack.setTextSize(18);
        btnBack.setOnClickListener(v -> finish());
        layout.addView(btnBack);

        setContentView(layout);

        // Load data
        groupId = getIntent().getIntExtra("groupId", -1);
        GroupDatabase db = Room.databaseBuilder(getApplicationContext(),
                        GroupDatabase.class, "GroupDB")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        groupDao = db.groupDao();
        eventDao = db.eventDao();

        // Get group info
        Group group = groupDao.getGroupById(groupId);
        if (group != null) {
            header.setText(group.getName() + " — Events");
        } else {
            header.setText("Group Details");
        }

        // Load events for this group
        eventList = eventDao.getEventsForGroup(groupId);
        eventDisplayList = new ArrayList<>();

        for (Event e : eventList) {
            String text = "• " + e.title + " — " +
                    (e.date == null || e.date.isEmpty() ? "No date" : e.date);
            eventDisplayList.add(text);
        }

        // Set adapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventDisplayList);
        listView.setAdapter(adapter);

        // Tap to open event details
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Event selectedEvent = eventList.get(position);
            Intent intent = new Intent(GroupDetailsActivity.this, EventDetailsActivity.class);
            intent.putExtra("eventId", selectedEvent.id);
            startActivity(intent);
        });

        // Long press to delete
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            Event selectedEvent = eventList.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Delete Event")
                    .setMessage("Delete \"" + selectedEvent.title + "\"?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        eventDao.deleteEvent(selectedEvent);
                        reloadEvents();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadEvents();
    }

    private void reloadEvents() {
        eventList = eventDao.getEventsForGroup(groupId);
        eventDisplayList.clear();
        for (Event e : eventList) {
            String text = "• " + e.title + " — " +
                    (e.date == null || e.date.isEmpty() ? "No date" : e.date);
            eventDisplayList.add(text);
        }
        adapter.notifyDataSetChanged();
    }
}
