package com.example.outthechat.view;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Launch GroupScreen directly
        Intent intent = new Intent(this, GroupScreen.class);
        startActivity(intent);
        finish(); // closes this activity so it doesn't stack
    }
}
