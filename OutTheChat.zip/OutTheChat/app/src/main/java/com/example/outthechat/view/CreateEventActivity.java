package com.example.outthechat.view;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import com.example.outthechat.view.MyWidget;

import com.example.outthechat.R;
import com.example.outthechat.model.Event;
import com.example.outthechat.model.EventDao;
import com.example.outthechat.model.Group;
import com.example.outthechat.model.GroupDao;
import com.example.outthechat.model.GroupDatabase;

import java.util.List;

public class CreateEventActivity extends AppCompatActivity {

    private GroupDatabase db;
    private GroupDao groupDao;
    private EventDao eventDao;

    private EditText eventNameInput, eventDateInput;
    private Spinner groupSpinner;
    private Button btnSaveEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Simple layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(60, 100, 60, 60);

        eventNameInput = new EditText(this);
        eventNameInput.setHint("Event name");
        layout.addView(eventNameInput);

        eventDateInput = new EditText(this);
        eventDateInput.setHint("Event date (e.g. Dec 5, 2025)");
        layout.addView(eventDateInput);

        groupSpinner = new Spinner(this);
        layout.addView(groupSpinner);

        btnSaveEvent = new Button(this);
        btnSaveEvent.setText("Save Event");
        layout.addView(btnSaveEvent);

        setContentView(layout);

        // Setup database
        db = Room.databaseBuilder(getApplicationContext(), GroupDatabase.class, "GroupDB")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();

        groupDao = db.groupDao();
        eventDao = db.eventDao();

        // Populate spinner with groups
        List<Group> groups = groupDao.getAllGroups();
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                groups.stream().map(Group::getName).toArray(String[]::new)
        );
        groupSpinner.setAdapter(spinnerAdapter);

        // Save event
        btnSaveEvent.setOnClickListener(v -> {
            String eventName = eventNameInput.getText().toString().trim();
            String eventDate = eventDateInput.getText().toString().trim();
            int selectedGroupPosition = groupSpinner.getSelectedItemPosition();

            if (eventName.isEmpty() || eventDate.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedGroupPosition == -1 || groups.isEmpty()) {
                Toast.makeText(this, "Please create a group first", Toast.LENGTH_SHORT).show();
                return;
            }

            Group selectedGroup = groups.get(selectedGroupPosition);
            Event newEvent = new Event(eventName, eventDate, "", selectedGroup.getId());
            eventDao.insertEvent(newEvent);

            Toast.makeText(this, "Event saved!", Toast.LENGTH_SHORT).show();

// Trigger the widget to refresh
            MyWidget.refreshWidget(getApplicationContext());

            finish();

            Intent intent = new Intent(CreateEventActivity.this, HomeScreen.class);
            startActivity(intent);
            finish();
        });
    }
}
